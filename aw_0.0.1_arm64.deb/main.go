package main

func main() {
	println("Ba dum, tzz!")
}