#!/bin/zsh

cd ..
dpkg-deb -b ./aw
dpkg-name ./aw.deb
dpkg-deb --contents ./aw.deb
cd ./aw