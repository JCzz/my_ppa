#!/bin/zsh

cd ..
dpkg-deb -b ./aw
dpkg-deb --contents ./aw
cd ./aw