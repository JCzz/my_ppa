// +build delve

package main

import (
	"fmt"
	"github.com/appsyouwear/power/library/plates/go/library/goto/build"
	"github.com/appsyouwear/power/library/plates/go/library/goto/tui/cmd"
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

func TestBuildThis(t *testing.T) {
	_cmd := cmd.New()
	_cmd.Prompt = cmd.Prompt{}.NewPrompt().(*cmd.Mock)
	_cmd.Prompt.(*cmd.Mock).AllYes = true

	_, filename, _, _ := runtime.Caller(0)
	dir := filepath.Dir(filename)
	// testDir := filepath.Join(dir, "test")
	outDirFile := filepath.Join(dir, "aw")
	// filepath.FromSlash()
	path, _ := os.Getwd()
	fmt.Println(path)

	build.Build(dir, outDirFile, "darwin", "arm64")
}

func TestBuildUbuntu(t *testing.T) {
	_cmd := cmd.New()
	_cmd.Prompt = cmd.Prompt{}.NewPrompt().(*cmd.Mock)
	_cmd.Prompt.(*cmd.Mock).AllYes = true

	_, filename, _, _ := runtime.Caller(0)
	dir := filepath.Dir(filename)
	// testDir := filepath.Join(dir, "test")
	outDirFile := filepath.Join(dir, "aw")
	// filepath.FromSlash()
	path, _ := os.Getwd()
	fmt.Println(path)

	build.Build(dir, outDirFile, "linux", "arm64")
}
