package main

func main() {
	println("Ba dum, tzz! Version 3")
}
